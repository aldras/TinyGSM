FIRMWARE UPDATE
*** DON'T FORGET 1V8 3V3 switch (SW1) if you are using the nRF9160DK to program an external target!!!
python3 flash_with_logging.py mfw_nrf9160_1.2.3.zip

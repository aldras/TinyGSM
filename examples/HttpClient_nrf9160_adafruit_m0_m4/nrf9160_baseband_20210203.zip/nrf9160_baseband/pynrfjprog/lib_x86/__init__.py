# 32 bit libraries

